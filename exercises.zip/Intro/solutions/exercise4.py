if __name__=="__main__":
	user=input("Please write your name: ")
	age=input("Please write your age: ")
	height=input("please write your height(in meters):")
	print(f"So you're {user} you're {age} years old and you're tall {height} m...")
function changeColor(argument) {
	document.querySelector('#square').style.backgroundColor=argument
}